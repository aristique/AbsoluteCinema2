﻿namespace ABSOLUTE_CINEMA.Domain.DTO
{
    public class UserViewModel
    {
        public string Name { get; set; }
        public string Email { get; set; }
        public string Roles { get; set; }
    }
}