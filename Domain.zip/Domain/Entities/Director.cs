﻿using System;

namespace ABSOLUTE_CINEMA.Domain.Entities
{
    public class Director
    {
        public Guid Id { get; set; }
        public string Name { get; set; }
    }
}