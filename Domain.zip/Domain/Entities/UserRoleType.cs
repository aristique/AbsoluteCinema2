﻿namespace ABSOLUTE_CINEMA.Domain.Entities
{
    public enum UserRoleType
    {
        None = 0,
        Guest = 1,
        User = 10,
        Admin = 100,
        Banned = 200
    }
}
